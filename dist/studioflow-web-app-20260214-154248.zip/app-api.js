(function () {
  const STORE_KEY = 'studioflow_v1';
  const STATUS_VALUES = ['pending', 'confirmed', 'completed', 'cancelled'];
  const PROVINCE_RATES = {
    'ON': 0.13, 'BC': 0.12, 'AB': 0.05, 'QC': 0.14975, 'NS': 0.15, 'NB': 0.15, 'MB': 0.12, 'SK': 0.11, 'PE': 0.15, 'NL': 0.15, 'CUSTOM': 0
  };

  function deepClone(value) { return JSON.parse(JSON.stringify(value)); }
  function uid(prefix) { return prefix + '_' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36); }

  function parseMinutes(time) {
    const parts = String(time || '').split(':').map(Number);
    if (parts.length !== 2 || Number.isNaN(parts[0]) || Number.isNaN(parts[1])) return NaN;
    return parts[0] * 60 + parts[1];
  }

  function toTime(minutes) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  function isISODate(value) { return /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')); }

  function normalizeClient(client) {
    return {
      id: client.id || uid('cli'),
      name: String(client.name || '').trim(),
      email: String(client.email || '').trim().toLowerCase(),
      phone: String(client.phone || '').trim().replace(/\D/g,''), // Store digits only
      credits: Number(client.credits || 0),
      referredBy: client.referredBy || 'Direct',
      joinedDate: client.joinedDate || new Date().toISOString()
    };
  }

  function loadState() {
    try {
      const current = localStorage.getItem(STORE_KEY);
      if (current) {
        const parsed = JSON.parse(current);
        return {
          services: parsed.services || [],
          bookings: parsed.bookings || [],
          clients: (parsed.clients || []).map(normalizeClient),
          expenses: parsed.expenses || [],
          taxConfig: parsed.taxConfig || { province: 'ON', rate: 0.13 }
        };
      }
    } catch (e) { console.error('State load failed:', e); }
    return { services: [], bookings: [], clients: [], expenses: [], taxConfig: { province: 'ON', rate: 0.13 } };
  }

  let state = loadState();
  function saveState() { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }

  const api = {
    utils: {
      safeText: (t) => String(t || '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])),
      formatMoney: (a) => new Intl.NumberFormat('en-CA', { style: 'currency', currency: 'CAD' }).format(a || 0)
    },

    // --- ONE-TAP REMINDER LOGIC ---
    async sendReminder(bookingId) {
      const b = state.bookings.find(x => x.id === bookingId);
      if (!b) return;
      
      const client = state.clients.find(c => c.email === b.clientEmail);
      const phone = client ? client.phone : b.clientPhone;
      
      if (!phone) throw new Error("No phone number available for this student.");

      const message = `Hi ${b.clientName}, just a friendly reminder of our ${b.serviceName} lesson today at ${b.time}! See you soon.`;
      const url = `https://wa.me/${phone.replace(/\D/g,'')}?text=${encodeURIComponent(message)}`;
      
      window.open(url, '_blank');
      return true;
    },

    // --- CREDIT SYSTEM ---
    async adjustCredits(email, amount) {
      const client = state.clients.find(c => c.email.toLowerCase() === email.toLowerCase());
      if (client) {
        client.credits = Math.max(0, (client.credits || 0) + amount);
        saveState();
        return client.credits;
      }
      throw new Error("Client not found.");
    },

    // --- CLIENTS ---
    async registerStudent(data) {
      const exists = state.clients.find(c => c.email === data.email.toLowerCase());
      if (exists) throw new Error("Email already registered.");
      const newStudent = normalizeClient(data);
      state.clients.push(newStudent);
      saveState();
      return deepClone(newStudent);
    },

    async listClients() {
      const counts = {};
      state.bookings.forEach((b) => {
        if (!counts[b.clientEmail]) counts[b.clientEmail] = { total: 0, pending: 0, confirmed: 0, completed: 0, cancelled: 0 };
        counts[b.clientEmail].total++;
        if (counts[b.clientEmail].hasOwnProperty(b.status)) {
            counts[b.clientEmail][b.status]++;
        }
      });
      return deepClone(state.clients).map(c => ({
        ...c,
        stats: counts[c.email] || { total: 0, pending: 0, confirmed: 0, completed: 0, cancelled: 0 }
      }));
    },

    // --- BOOKINGS ---
    async listBookings(f = {}) {
      let rows = state.bookings.slice();
      if (f.date) rows = rows.filter(b => b.date === f.date);
      if (f.clientEmail) rows = rows.filter(b => b.clientEmail.toLowerCase() === f.clientEmail.toLowerCase());
      if (f.status && f.status !== 'all') rows = rows.filter(b => b.status === f.status);
      return deepClone(rows.sort((a, b) => a.time.localeCompare(b.time)));
    },

    async createBooking(p) {
      let client = state.clients.find(c => c.email.toLowerCase() === p.clientEmail.toLowerCase());
      if (!client) {
        client = normalizeClient({ name: p.clientName, email: p.clientEmail, phone: p.clientPhone || '' });
        state.clients.push(client);
      }
      const service = state.services.find(s => s.id === p.serviceId);
      const booking = {
        id: uid('book'),
        ...p,
        serviceName: service ? service.name : 'Session',
        status: p.status || 'pending',
        createdAt: new Date().toISOString()
      };
      state.bookings.push(booking);
      saveState();
      return deepClone(booking);
    },

    async updateBookingStatus(id, status) {
      const b = state.bookings.find(x => x.id === id);
      if (b && STATUS_VALUES.includes(status)) {
        b.status = status;
        saveState();
      }
      return deepClone(b);
    },

    // --- SERVICES ---
    async listServices() { return deepClone(state.services); },

    async saveService(payload) {
      if (payload.id) {
        const idx = state.services.findIndex(s => s.id === payload.id);
        state.services[idx] = { ...state.services[idx], ...payload };
      } else {
        state.services.push({ id: uid('svc'), weeklySlots: [], ...payload });
      }
      saveState();
      return true;
    },

    async deleteService(id) {
      state.services = state.services.filter(s => s.id !== id);
      saveState();
      return true;
    },

    async listBookableSlots(serviceId, date) {
      const service = state.services.find(s => s.id === serviceId);
      if (!service || !isISODate(date)) return [];
      const day = new Date(`${date}T00:00:00`).getDay();
      const slots = (service.weeklySlots || []).filter(s => Number(s.day) === day);
      const times = [];
      slots.forEach(s => {
        let cursor = parseMinutes(s.start);
        const end = parseMinutes(s.end);
        const dur = Number(service.duration) || 30;
        while (cursor + dur <= end) {
          times.push(toTime(cursor));
          cursor += dur;
        }
      });
      return times.map(time => {
        const used = state.bookings.filter(b => b.date === date && b.time === time && b.status !== 'cancelled').length;
        return { time, available: used < (service.capacity || 1) };
      });
    },

    // --- FINANCES & TAX ---
    async addExpense(data) {
      const exp = { id: uid('exp'), date: new Date().toISOString().split('T')[0], ...data, amount: Number(data.amount) };
      state.expenses.push(exp);
      saveState();
      return exp;
    },

    async setTaxConfig(province, customRate = 0) {
      state.taxConfig = { province, rate: province === 'CUSTOM' ? customRate : PROVINCE_RATES[province] };
      saveState();
      return state.taxConfig;
    },

    async getTaxConfig() { return state.taxConfig; },

    async getFinancialSummary() {
      const completed = state.bookings.filter(b => b.status === 'completed');
      const gross = completed.reduce((sum, b) => sum + (Number(b.price) || 0), 0);
      const expenses = state.expenses.reduce((sum, e) => sum + e.amount, 0);
      const tax = gross * state.taxConfig.rate;
      return { gross, expenses, tax, profit: gross - expenses - tax };
    },

    async getWeeklyEarnings() {
      const labels = []; const dataPoints = []; const today = new Date();
      for (let i = 6; i >= 0; i--) {
        const d = new Date(); d.setDate(today.getDate() - i);
        const iso = d.toISOString().split('T')[0];
        labels.push(d.toLocaleDateString('en-US', { weekday: 'short' }));
        const dayTotal = state.bookings
          .filter(b => b.date === iso && b.status === 'completed')
          .reduce((sum, b) => sum + (Number(b.price) || 0), 0);
        dataPoints.push(dayTotal);
      }
      return { labels, dataPoints };
    },

    // --- DATA PORTABILITY ---
    async exportSystemData() {
        const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `studioflow_backup_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
    }
  };

  window.StudioFlowAPI = api;
})();