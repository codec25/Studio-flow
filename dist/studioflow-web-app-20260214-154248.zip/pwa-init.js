(function () {
  if (!('serviceWorker' in navigator)) return;

  let deferredPrompt = null;
  let installButton = null;

  function isStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  }

  function ensureInstallButton() {
    if (installButton || isStandalone()) return;
    installButton = document.createElement('button');
    installButton.id = 'installAppBtn';
    installButton.textContent = 'Install App';
    installButton.type = 'button';
    installButton.style.cssText = [
      'position:fixed',
      'right:16px',
      'bottom:16px',
      'z-index:9999',
      'padding:10px 14px',
      'border-radius:999px',
      'border:1px solid #0f766e',
      'background:#0f766e',
      'color:#fff',
      'font-weight:800',
      'font-size:13px',
      'box-shadow:0 8px 20px rgba(15,118,110,0.25)',
      'display:none',
      'cursor:pointer'
    ].join(';');

    installButton.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      installButton.style.display = 'none';
    });

    document.body.appendChild(installButton);
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    ensureInstallButton();
    installButton.style.display = 'inline-flex';
    installButton.style.alignItems = 'center';
    installButton.style.gap = '6px';
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    if (installButton) installButton.style.display = 'none';
  });

  window.addEventListener('load', async () => {
    try {
      await navigator.serviceWorker.register('sw.js');
    } catch (error) {
      console.error('Service worker registration failed:', error);
    }
  });
})();
