(function () {
  const STORE_KEY = 'studioflow_v3';
  const STUDENT_SESSION_KEY = 'studioflow_student_session';
  const TEACHER_SESSION_KEY = 'studioflow_teacher_session';
  const SUGGESTIONS_KEY = 'studioflow_suggestions_v1';
  const STATUS_VALUES = ['pending', 'confirmed', 'completed', 'cancelled', 'cancelled_late'];

  // --- UTILITIES ---
  function deepClone(value) { return JSON.parse(JSON.stringify(value)); }
  function uid(prefix) { return prefix + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36); }
  function parseMinutes(time) {
    const [h, m] = String(time || '').split(':').map(Number);
    return Number.isNaN(h) || Number.isNaN(m) ? NaN : h * 60 + m;
  }
  function toTime(totalMinutes) {
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }
  function safeText(text) {
    return String(text || '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
  }
  function loadSuggestions() {
    try { return JSON.parse(localStorage.getItem(SUGGESTIONS_KEY) || '{}'); } catch (_) { return {}; }
  }
  function saveSuggestions(map) {
    localStorage.setItem(SUGGESTIONS_KEY, JSON.stringify(map));
  }

  async function hashPassword(raw) {
    const input = String(raw || '');
    if (!input) return '';
    if (globalThis.crypto && crypto.subtle && globalThis.TextEncoder) {
      const bytes = new TextEncoder().encode(input);
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
    }
    return 'plain:' + input;
  }

  // --- NORMALIZATION ---
  function normalizeService(service) {
    return {
      id: service.id || uid('svc'),
      name: String(service.name || '').trim(),
      duration: Number(service.duration || 30),
      price: Number(service.price || 0),
      capacity: Math.max(1, Number(service.capacity || 1)),
      weeklySlots: Array.isArray(service.weeklySlots) ? service.weeklySlots : []
    };
  }

  function normalizeStudent(student) {
    return {
      id: student.id || uid('stu'),
      name: String(student.name || '').trim(),
      email: String(student.email || '').trim().toLowerCase(),
      phone: String(student.phone || '').replace(/[^0-9+]/g, ''),
      passwordHash: String(student.passwordHash || ''),
      credits: Number(student.credits || 0),
      isSubscription: student.isSubscription === true,
      lastSubscriptionRefill: String(student.lastSubscriptionRefill || ''),
      isActive: student.isActive !== false
    };
  }

  function normalizeBooking(booking) {
    return {
      id: booking.id || uid('book'),
      clientName: String(booking.clientName || '').trim(),
      clientEmail: String(booking.clientEmail || '').trim().toLowerCase(),
      serviceId: booking.serviceId || '',
      serviceName: String(booking.serviceName || ''),
      date: String(booking.date || ''),
      time: String(booking.time || ''),
      notes: String(booking.notes || ''), // Original booking notes
      teacherNotes: String(booking.teacherNotes || ''), // Notes from teacher after lesson
      homework: String(booking.homework || ''), // Homework assigned
      price: Number(booking.price || 0),
      status: STATUS_VALUES.includes(booking.status) ? booking.status : 'pending',
      createdAt: booking.createdAt || new Date().toISOString()
    };
  }

  function normalizeRecap(recap) {
    return {
      id: recap.id || uid('recap'),
      bookingId: String(recap.bookingId || ''),
      studentEmail: String(recap.studentEmail || '').trim().toLowerCase(),
      studentName: String(recap.studentName || '').trim(),
      serviceName: String(recap.serviceName || '').trim(),
      date: String(recap.date || ''),
      time: String(recap.time || ''),
      summary: String(recap.summary || '').trim(),
      resources: Array.isArray(recap.resources)
        ? recap.resources.map((x) => String(x || '').trim()).filter(Boolean)
        : [],
      createdAt: recap.createdAt || new Date().toISOString(),
      teacherEmail: String(recap.teacherEmail || '').trim().toLowerCase()
    };
  }

  function monthKey(dateValue) {
    const d = dateValue instanceof Date ? dateValue : new Date(dateValue || Date.now());
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  function refillSubscriptionCreditsIfNeeded(now) {
    const key = monthKey(now);
    let changed = false;
    let refilled = 0;
    state.students.forEach((student) => {
      if (student.isSubscription !== true) return;
      if (student.lastSubscriptionRefill === key) return;
      student.credits = 4;
      student.lastSubscriptionRefill = key;
      changed = true;
      refilled += 1;
    });
    if (changed) saveState();
    return refilled;
  }

  function parseResourceLinks(raw) {
    if (Array.isArray(raw)) {
      return raw.map((x) => String(x || '').trim()).filter((x) => /^https?:\/\//i.test(x));
    }
    return String(raw || '')
      .split(/[\n,]+/g)
      .map((x) => x.trim())
      .filter((x) => /^https?:\/\//i.test(x));
  }

  // --- STATE PERSISTENCE ---
  function emptyState() {
    return {
      services: [], bookings: [], students: [], teachers: [],
      packages: [
        {id: 1, name: "Single Session", count: 1, price: 60},
        {id: 2, name: "5-Lesson Pack", count: 5, price: 275},
        {id: 3, name: "10-Lesson Pack", count: 10, price: 500}
      ],
      lessonRecaps: [],
      ledger: [],
      expenses: [],
      settings: { cancelWindow: 24, lateFee: 50, allowPortalCancel: true, taxRate: 0.20 },
    };
  }

  function loadState() {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return emptyState();
    try {
      const parsed = JSON.parse(raw);
      return {
        ...emptyState(),
        ...parsed,
        services: (parsed.services || []).map(normalizeService),
        bookings: (parsed.bookings || []).map(normalizeBooking),
        students: (parsed.students || []).map(normalizeStudent),
        lessonRecaps: (parsed.lessonRecaps || []).map(normalizeRecap)
      };
    } catch (e) { return emptyState(); }
  }

  let state = loadState();
  refillSubscriptionCreditsIfNeeded();
  function saveState() { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }

  function addSuggestion(key, value) {
    const v = String(value || '').trim();
    if (!v || v.length < 2) return;
    const map = loadSuggestions();
    const arr = Array.isArray(map[key]) ? map[key] : [];
    map[key] = [v, ...arr.filter(x => x !== v)].slice(0, 15);
    saveSuggestions(map);
  }

  // --- INTERNAL SELECTORS ---
  const getStudentByEmail = (email) => state.students.find(s => s.email === String(email).toLowerCase());
  const getTeacherByEmail = (email) => state.teachers.find(t => t.email === String(email).toLowerCase());
  const getServiceById = (id) => state.services.find(s => s.id === id);

  // --- API DEFINITION ---
  const api = {
    utils: {
      safeText,
      formatMoney: (v) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(v || 0))
    },

    // --- AUTH ---
    async loginStudent(email, password) {
      const user = getStudentByEmail(email);
      if (!user) throw new Error('Account not found.');
      const hash = await hashPassword(password);
      if (hash !== user.passwordHash) throw new Error('Invalid password.');
      localStorage.setItem(STUDENT_SESSION_KEY, user.email);
      return deepClone(user);
    },

    async getCurrentStudent() {
      refillSubscriptionCreditsIfNeeded();
      const email = localStorage.getItem(STUDENT_SESSION_KEY);
      const student = email ? getStudentByEmail(email) : null;
      return student ? deepClone(student) : null;
    },

    async registerStudent(data) {
      if (getStudentByEmail(data.email)) throw new Error('Email already exists.');
      const isSubscription = data.isSubscription === true;
      const student = normalizeStudent({
        ...data,
        passwordHash: await hashPassword(data.password),
        isSubscription,
        credits: isSubscription ? Math.max(4, Number(data.credits || 0)) : Number(data.credits || 0),
        lastSubscriptionRefill: isSubscription ? monthKey() : ''
      });
      state.students.push(student);
      addSuggestion('emails', student.email);
      addSuggestion('names', student.name);
      saveState();
      return deepClone(student);
    },

    async getCurrentTeacher() {
      const email = localStorage.getItem(TEACHER_SESSION_KEY);
      const teacher = email ? getTeacherByEmail(email) : null;
      return teacher ? deepClone(teacher) : null;
    },

    async loginTeacher(email, password) {
      const user = getTeacherByEmail(email);
      if (!user) throw new Error('Teacher account not found.');
      const hash = await hashPassword(password);
      if (hash !== user.passwordHash) throw new Error('Invalid password.');
      localStorage.setItem(TEACHER_SESSION_KEY, user.email);
      return deepClone(user);
    },

    async registerTeacher(data) {
      if (getTeacherByEmail(data.email)) throw new Error('Teacher email already exists.');
      const teacher = {
        id: uid('tch'),
        name: String(data.name || '').trim(),
        email: String(data.email || '').trim().toLowerCase(),
        passwordHash: await hashPassword(data.password)
      };
      state.teachers.push(teacher);
      addSuggestion('emails', teacher.email);
      addSuggestion('names', teacher.name);
      saveState();
      return deepClone(teacher);
    },

    // --- SERVICES & PACKAGES ---
    async listServices() { return deepClone(state.services); },
    async createService(data) {
      const svc = normalizeService(data);
      svc.weeklySlots = (svc.weeklySlots || []).map(slot => ({ ...slot, day: Number(slot.day) }));
      state.services.push(svc);
      addSuggestion('serviceNames', svc.name);
      saveState();
      return svc;
    },
    async deleteService(id) {
      state.services = state.services.filter(s => s.id !== id);
      saveState();
    },
    async getPackages() { return deepClone(state.packages); },
    async savePackages(newPacks) { state.packages = newPacks; saveState(); },

    // --- SLOTS & CALENDAR ---
    async listBookableSlots(serviceId, date) {
      const service = getServiceById(serviceId);
      if (!service) return [];
      
      const [yy, mm, dd] = String(date).split('-').map(Number);
      if (!yy || !mm || !dd) return [];
      const dayIndex = new Date(Date.UTC(yy, mm - 1, dd)).getUTCDay();
      const daySchedules = (service.weeklySlots || []).filter(s => Number(s.day) === dayIndex && s.active !== false);
      if (!daySchedules.length) return [];

      const slots = [];
      daySchedules.forEach(daySchedule => {
        let current = parseMinutes(daySchedule.start);
        const end = parseMinutes(daySchedule.end);
        while (current + service.duration <= end) {
          const timeLabel = toTime(current);
          const bookings = state.bookings.filter(b =>
            b.serviceId === serviceId &&
            b.date === date &&
            b.time === timeLabel &&
            b.status !== 'cancelled'
          );
          slots.push({
            time: timeLabel,
            available: bookings.length < service.capacity,
            openSpots: Math.max(0, service.capacity - bookings.length)
          });
          current += service.duration;
        }
      });
      const dedup = {};
      slots.forEach(s => { dedup[s.time] = s; });
      return Object.values(dedup).sort((a,b) => a.time.localeCompare(b.time));
    },

    async getLowCreditStudents(limit = 1) {
      refillSubscriptionCreditsIfNeeded();
      return deepClone(state.students.filter(s => Number(s.credits || 0) <= Number(limit)).sort((a,b) => a.credits - b.credits));
    },

    async listExpenses() {
      return deepClone(state.expenses || []);
    },

    async rememberSuggestion(key, value) {
      addSuggestion(key, value);
    },

    async getSuggestions(key) {
      const map = loadSuggestions();
      return deepClone(map[key] || []);
    },

    // --- LEDGER & TRANSACTIONS ---
    async logTransaction(clientEmail, type, amount, description, revenue = 0, packageName = '') {
      state.ledger.push({
        id: uid('tx'),
        date: new Date().toISOString(),
        clientEmail: clientEmail.toLowerCase(),
        clientName: getStudentByEmail(clientEmail)?.name || "Unknown",
        type, 
        amount,
        revenue, 
        packageName,
        description
      });
      saveState();
    },

    async getTransactions() { return deepClone(state.ledger); },

    async getStudentLedger(email) {
      return state.ledger
        .filter(tx => tx.clientEmail === email.toLowerCase())
        .sort((a,b) => new Date(b.date) - new Date(a.date));
    },

    async purchasePackage(email, packageId) {
      const pkg = state.packages.find(p => p.id == packageId);
      if (!pkg) throw new Error("Package not found");
      
      await this.adjustCredits(email, pkg.count);
      await this.logTransaction(email, 'credit_in', pkg.count, `Purchased: ${pkg.name}`, pkg.price, pkg.name);
      return { newTotal: getStudentByEmail(email).credits };
    },

    // --- EXPENSES ---
    async addExpense(data) {
      state.expenses.push({
        id: uid('exp'),
        date: new Date().toISOString(),
        note: data.note,
        amount: Number(data.amount)
      });
      saveState();
    },

    // --- BOOKINGS & LESSON NOTES ---
    async createBooking(data) {
      refillSubscriptionCreditsIfNeeded();
      const student = getStudentByEmail(data.clientEmail);
      if (!student) throw new Error("Student account not found.");
      const isForced = data.force === true;
      if (!isForced && student.credits < 1) throw new Error("Insufficient credits. Please purchase a package.");
      
      const service = getServiceById(data.serviceId);
      const booking = normalizeBooking({ ...data, serviceName: service.name, price: service.price });
      
      state.bookings.push(booking);
      if (student.credits > 0) {
        await this.adjustCredits(student.email, -1);
        await this.logTransaction(student.email, 'credit_out', 1, `Booking: ${service.name}`);
      }
      addSuggestion('emails', student.email);
      addSuggestion('notes', booking.notes);
      saveState();
      return booking;
    },

    async listBookings(filter = {}) {
      let b = [...state.bookings];
      if (filter.clientEmail) b = b.filter(x => x.clientEmail === filter.clientEmail.toLowerCase());
      if (filter.date) b = b.filter(x => x.date === filter.date);
      return deepClone(b);
    },

    async getBookingDetails(bookingId) {
      return deepClone(state.bookings.find(x => x.id === bookingId));
    },

    async updateBookingNotes(bookingId, teacherNotes, homework) {
      const b = state.bookings.find(x => x.id === bookingId);
      if (!b) throw new Error("Booking not found");
      
      b.teacherNotes = teacherNotes;
      b.homework = homework;
      b.status = 'completed';
      saveState();
      return b;
    },

    async updateBookingStatus(bookingId, newStatus) {
      const b = state.bookings.find(x => x.id === bookingId);
      if (!b) throw new Error("Booking not found");
      b.status = newStatus;
      saveState();
    },

    // --- CANCELLATION LOGIC ---
    async calculateCancellationTerms(bookingId) {
      const b = state.bookings.find(x => x.id === bookingId);
      if (!b) throw new Error("Booking not found");
      
      const now = new Date();
      const lessonTime = new Date(`${b.date}T${b.time}`);
      const hoursDiff = (lessonTime - now) / (1000 * 60 * 60);
      
      if (hoursDiff < state.settings.cancelWindow) {
        return { fee: 1, message: `Less than ${state.settings.cancelWindow}h notice. No credit refund.` };
      }
      return { fee: 0, message: "Early cancellation. Credit will be refunded." };
    },

    // --- CREDITS & NOTIFICATIONS ---
    async listClients() {
      refillSubscriptionCreditsIfNeeded();
      return deepClone(state.students);
    },
    
    async setStudentSubscription(email, isSubscription) {
      const student = getStudentByEmail(email);
      if (!student) throw new Error('Student not found.');
      student.isSubscription = isSubscription === true;
      if (student.isSubscription && !student.lastSubscriptionRefill) {
        student.lastSubscriptionRefill = monthKey();
        if (student.credits < 4) student.credits = 4;
      }
      if (!student.isSubscription) student.lastSubscriptionRefill = '';
      saveState();
      return deepClone(student);
    },

    async runMonthStartCheck() {
      const refilled = refillSubscriptionCreditsIfNeeded();
      return { refilled, month: monthKey() };
    },
    
    async adjustCredits(email, amount) {
      refillSubscriptionCreditsIfNeeded();
      const student = getStudentByEmail(email);
      if (student) {
        student.credits = Math.max(0, student.credits + amount);
        saveState();
      }
    },

    async getPendingReminders() {
      const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      return state.bookings.filter(b => b.date === tomorrow && b.status === 'confirmed');
    },

    async getUpcomingLessonNudges(hours = 24) {
      const now = new Date();
      const maxMs = Number(hours || 24) * 60 * 60 * 1000;
      return deepClone(
        state.bookings
          .filter((b) => b.status === 'confirmed' || b.status === 'pending')
          .map((b) => {
            const when = new Date(`${b.date}T${b.time}`);
            if (Number.isNaN(when.getTime())) return null;
            return {
              ...b,
              startsAt: when.toISOString(),
              hoursLeft: Number(((when.getTime() - now.getTime()) / (60 * 60 * 1000)).toFixed(1))
            };
          })
          .filter(Boolean)
          .filter((b) => {
            const diff = new Date(b.startsAt).getTime() - now.getTime();
            return diff >= 0 && diff <= maxMs;
          })
          .sort((a, b) => new Date(a.startsAt) - new Date(b.startsAt))
      );
    },

    async generateReminderLinks(bookingId) {
      const b = state.bookings.find(x => x.id === bookingId);
      if (!b) return null;
      const msg = `Hi ${b.clientName}, reminder for your ${b.serviceName} tomorrow at ${b.time}. See you then!`;
      return {
        whatsapp: `https://wa.me/${b.clientPhone || ''}?text=${encodeURIComponent(msg)}`,
        email: `mailto:${b.clientEmail}?subject=Reminder&body=${encodeURIComponent(msg)}`
      };
    },

    async getEmailTemplate(type, data) {
      if (type === 'PURCHASE_RECEIPT') {
        const body = `Hi ${data.clientName},\n\nThank you for your purchase!\nPackage: ${data.packageName}\nCredits Added: ${data.credits}\nAmount: $${data.amount}\n\nBook your sessions in the portal.\n\nBest,\nStudioFlow Team`;
        return {
          mailto: `mailto:${data.clientEmail}?subject=Receipt&body=${encodeURIComponent(body)}`
        };
      }
    },

    // --- FINANCIAL REPORTING ---
    async getFinancialSummary() {
      const gross = state.ledger.reduce((acc, tx) => acc + (tx.revenue || 0), 0);
      const expenses = state.expenses.reduce((acc, exp) => acc + exp.amount, 0);
      const tax = (gross - expenses) > 0 ? (gross - expenses) * (state.settings.taxRate || 0.2) : 0;
      return { gross, expenses, tax, profit: gross - expenses - tax };
    },

    async createLessonRecap(payload) {
      const booking = state.bookings.find((x) => x.id === payload.bookingId);
      if (!booking) throw new Error('Booking not found.');
      const summary = String(payload.summary || '').trim();
      if (!summary) throw new Error('Recap summary is required.');

      const recap = normalizeRecap({
        bookingId: booking.id,
        studentEmail: booking.clientEmail,
        studentName: booking.clientName,
        serviceName: booking.serviceName,
        date: booking.date,
        time: booking.time,
        summary,
        resources: parseResourceLinks(payload.resources),
        teacherEmail: localStorage.getItem(TEACHER_SESSION_KEY) || ''
      });

      const existingIndex = state.lessonRecaps.findIndex((r) => r.bookingId === booking.id);
      if (existingIndex >= 0) state.lessonRecaps.splice(existingIndex, 1, recap);
      else state.lessonRecaps.push(recap);

      saveState();
      return deepClone(recap);
    },

    async listLessonRecaps(filter = {}) {
      let rows = [...state.lessonRecaps];
      if (filter.studentEmail) {
        const email = String(filter.studentEmail).toLowerCase();
        rows = rows.filter((x) => x.studentEmail === email);
      }
      if (filter.bookingId) rows = rows.filter((x) => x.bookingId === filter.bookingId);
      rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      return deepClone(rows);
    },

    async deleteCurrentStudent() {
      const email = localStorage.getItem(STUDENT_SESSION_KEY);
      if (!email) throw new Error("No active session");
      state.students = state.students.filter(s => s.email !== email);
      state.bookings = state.bookings.filter(b => b.clientEmail !== email);
      localStorage.removeItem(STUDENT_SESSION_KEY);
      saveState();
    }
  };

  window.StudioFlowAPI = api;

  // Global UX: Enter key submit + native suggestions via datalist
  if (typeof document !== 'undefined') {
    const initGlobalUx = () => {
      const map = {
        email: 'emails',
        regEmail: 'emails',
        loginEmail: 'emails',
        clientEmail: 'emails',
        name: 'names',
        regName: 'names',
        srvName: 'serviceNames',
        expNote: 'notes',
        clientNotes: 'notes'
      };

      const getListId = (key) => `sf-suggest-${key}`;
      const ensureList = (key) => {
        const id = getListId(key);
        let dl = document.getElementById(id);
        if (!dl) {
          dl = document.createElement('datalist');
          dl.id = id;
          document.body.appendChild(dl);
        }
        const mapData = loadSuggestions();
        dl.innerHTML = (mapData[key] || []).map(v => `<option value="${safeText(v)}"></option>`).join('');
        return id;
      };

      Object.entries(map).forEach(([id, key]) => {
        const el = document.getElementById(id);
        if (!el) return;
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          el.setAttribute('list', ensureList(key));
          if (id.toLowerCase().includes('email')) el.setAttribute('autocomplete', 'email');
          if (id.toLowerCase().includes('name')) el.setAttribute('autocomplete', 'name');
          el.addEventListener('blur', () => {
            addSuggestion(key, el.value);
            ensureList(key);
          });
        }
      });

      document.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return;
        const target = e.target;
        if (!target || target.tagName === 'TEXTAREA') return;
        if (!['INPUT', 'SELECT'].includes(target.tagName)) return;

        const form = target.closest('form');
        if (form) {
          e.preventDefault();
          const submitBtn = form.querySelector('button[type="submit"], input[type="submit"], #submitBtn, #btnMainAction, #btnLogin, #btnBook');
          if (submitBtn) submitBtn.click();
          else if (typeof form.requestSubmit === 'function') form.requestSubmit();
          return;
        }

        const scope = target.closest('.card, main, section, body') || document.body;
        const actionBtn = scope.querySelector('#btnMainAction, #loginBtn, #submitBtn, #btnBook, .btn-primary, .btn-action, .cta-book');
        if (actionBtn && !actionBtn.disabled) {
          e.preventDefault();
          actionBtn.click();
        }
      });
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initGlobalUx);
    else initGlobalUx();
  }
})();
