(function () {
  const STORE_KEY = 'studioflow_v2';
  const LEGACY_KEYS = ['studioflow_v1', 'studiopro_master_v1', 'studio_v2'];
  const SESSION_KEY = 'studioflow_student_session';
  const STATUS_VALUES = ['pending', 'confirmed', 'completed', 'cancelled'];
  const PROVINCE_RATES = {
    ON: 0.13,
    BC: 0.12,
    AB: 0.05,
    QC: 0.14975,
    NS: 0.15,
    NB: 0.15,
    MB: 0.12,
    SK: 0.11,
    PE: 0.15,
    NL: 0.15,
    CUSTOM: 0
  };

  function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function uid(prefix) {
    return prefix + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36);
  }

  function parseMinutes(time) {
    const [h, m] = String(time || '').split(':').map(Number);
    if (Number.isNaN(h) || Number.isNaN(m)) return NaN;
    return h * 60 + m;
  }

  function toTime(totalMinutes) {
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }

  function isISODate(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ''));
  }

  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
  }

  function isPhone(value) {
    if (!value) return true;
    return /^[0-9+()\-\s]{7,20}$/.test(String(value));
  }

  function cleanPhone(value) {
    return String(value || '').replace(/[^0-9+]/g, '');
  }

  function safeText(text) {
    return String(text || '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  async function hashPassword(raw) {
    const input = String(raw || '');
    if (!input) return '';

    if (globalThis.crypto && crypto.subtle && globalThis.TextEncoder) {
      const bytes = new TextEncoder().encode(input);
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
    }

    return 'plain:' + input;
  }

  function normalizeService(service) {
    return {
      id: service.id || uid('svc'),
      name: String(service.name || '').trim(),
      duration: Number(service.duration || 0),
      price: Number(service.price || 0),
      capacity: Math.max(1, Number(service.capacity || 1)),
      weeklySlots: Array.isArray(service.weeklySlots)
        ? service.weeklySlots.map((slot) => ({
            id: slot.id || uid('slot'),
            day: Number(slot.day),
            start: String(slot.start || ''),
            end: String(slot.end || '')
          }))
        : []
    };
  }

  function normalizeClient(client) {
    return {
      id: client.id || uid('cli'),
      name: String(client.name || '').trim(),
      email: String(client.email || '').trim().toLowerCase(),
      phone: cleanPhone(client.phone || ''),
      passwordHash: String(client.passwordHash || ''),
      credits: Math.max(0, Number(client.credits || 0)),
      referredBy: String(client.referredBy || 'Direct'),
      joinedDate: client.joinedDate || new Date().toISOString(),
      lastLoginAt: client.lastLoginAt || null,
      isActive: client.isActive !== false
    };
  }

  function normalizeBooking(booking) {
    return {
      id: booking.id || uid('book'),
      clientId: booking.clientId || '',
      clientName: String(booking.clientName || '').trim(),
      clientEmail: String(booking.clientEmail || '').trim().toLowerCase(),
      clientPhone: cleanPhone(booking.clientPhone || ''),
      serviceId: booking.serviceId || '',
      serviceName: String(booking.serviceName || ''),
      date: String(booking.date || ''),
      time: String(booking.time || ''),
      notes: String(booking.notes || ''),
      price: Number(booking.price || 0),
      status: STATUS_VALUES.includes(booking.status) ? booking.status : 'pending',
      createdAt: booking.createdAt || new Date().toISOString(),
      updatedAt: booking.updatedAt || new Date().toISOString()
    };
  }

  function normalizeExpense(expense) {
    return {
      id: expense.id || uid('exp'),
      note: String(expense.note || ''),
      amount: Number(expense.amount || 0),
      category: String(expense.category || 'General'),
      date: String(expense.date || new Date().toISOString().split('T')[0])
    };
  }

  function normalizeAudit(event) {
    return {
      id: event.id || uid('audit'),
      ts: event.ts || new Date().toISOString(),
      action: String(event.action || 'unknown'),
      actor: String(event.actor || 'system'),
      details: String(event.details || '')
    };
  }

  function emptyState() {
    return {
      services: [],
      bookings: [],
      clients: [],
      expenses: [],
      taxConfig: { province: 'ON', rate: PROVINCE_RATES.ON },
      auditTrail: []
    };
  }

  function migrateLegacy(raw) {
    if (!raw || typeof raw !== 'object') return null;

    const migrated = emptyState();
    migrated.services = (raw.services || raw.classes || []).map(normalizeService);
    migrated.bookings = (raw.bookings || []).map(normalizeBooking);
    migrated.clients = (raw.clients || []).map(normalizeClient);
    migrated.expenses = (raw.expenses || []).map(normalizeExpense);
    migrated.taxConfig = raw.taxConfig || migrated.taxConfig;
    migrated.auditTrail = (raw.auditTrail || []).map(normalizeAudit);

    return migrated;
  }

  function loadState() {
    for (const key of [STORE_KEY, ...LEGACY_KEYS]) {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const parsed = JSON.parse(raw);
        const migrated = migrateLegacy(parsed);
        if (migrated) return migrated;
      } catch (error) {
        console.error('State load failed:', error);
      }
    }
    return emptyState();
  }

  let state = loadState();

  function saveState() {
    localStorage.setItem(STORE_KEY, JSON.stringify(state));
  }

  function logAudit(action, details, actor) {
    state.auditTrail.unshift(normalizeAudit({ action, details, actor: actor || 'system' }));
    state.auditTrail = state.auditTrail.slice(0, 500);
  }

  function getStudentByEmail(email) {
    return state.clients.find((c) => c.email === String(email || '').trim().toLowerCase());
  }

  function getServiceById(serviceId) {
    return state.services.find((s) => s.id === serviceId);
  }

  function setSessionEmail(email) {
    if (email) localStorage.setItem(SESSION_KEY, email);
    else localStorage.removeItem(SESSION_KEY);
  }

  function getSessionEmail() {
    return localStorage.getItem(SESSION_KEY);
  }

  function ensureServiceAndDate(serviceId, date) {
    const service = getServiceById(serviceId);
    if (!service) throw new Error('Service not found.');
    if (!isISODate(date)) throw new Error('Invalid date format. Use YYYY-MM-DD.');
    return service;
  }

  function buildSlots(service, date) {
    const day = new Date(date + 'T00:00:00').getDay();
    const dayBlocks = (service.weeklySlots || []).filter((slot) => Number(slot.day) === day);
    const slots = [];

    dayBlocks.forEach((block) => {
      let cursor = parseMinutes(block.start);
      const end = parseMinutes(block.end);
      while (cursor + service.duration <= end) {
        slots.push(toTime(cursor));
        cursor += service.duration;
      }
    });

    return [...new Set(slots)].sort();
  }

  const api = {
    utils: {
      safeText,
      formatMoney(amount) {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(amount || 0));
      }
    },

    async hasStudentAccount(email) {
      return Boolean(getStudentByEmail(email));
    },

    async registerStudent(data) {
      const name = String(data.name || '').trim();
      const email = String(data.email || '').trim().toLowerCase();
      const phone = cleanPhone(data.phone || '');
      const password = String(data.password || '');

      if (!name) throw new Error('Name is required.');
      if (!isEmail(email)) throw new Error('Valid email is required.');
      if (!isPhone(phone)) throw new Error('Phone format is invalid.');
      if (password.length < 6) throw new Error('Password must be at least 6 characters.');
      if (getStudentByEmail(email)) throw new Error('Email already registered.');

      const student = normalizeClient({
        name,
        email,
        phone,
        passwordHash: await hashPassword(password),
        credits: Number(data.credits || 0),
        referredBy: data.referredBy || 'Direct',
        joinedDate: data.joinedDate || new Date().toISOString()
      });

      state.clients.push(student);
      logAudit('student.registered', `Registered ${student.email}`, student.email);
      saveState();
      return deepClone(student);
    },

    async verifyStudentCredentials(email, password) {
      const student = getStudentByEmail(email);
      if (!student || !student.isActive) return false;
      const hash = await hashPassword(password);
      return hash === student.passwordHash;
    },

    async loginStudent(email, password) {
      const student = getStudentByEmail(email);
      if (!student || !student.isActive) throw new Error('Account not found.');

      const valid = await api.verifyStudentCredentials(email, password);
      if (!valid) throw new Error('Invalid email or password.');

      student.lastLoginAt = new Date().toISOString();
      setSessionEmail(student.email);
      logAudit('student.login', `Portal login ${student.email}`, student.email);
      saveState();
      return deepClone(student);
    },

    async logoutStudent() {
      const email = getSessionEmail();
      setSessionEmail('');
      if (email) {
        logAudit('student.logout', `Portal logout ${email}`, email);
        saveState();
      }
      return true;
    },

    async getCurrentStudent() {
      const email = getSessionEmail();
      if (!email) return null;
      const student = getStudentByEmail(email);
      return student ? deepClone(student) : null;
    },

    async listClients() {
      const counts = {};
      state.bookings.forEach((booking) => {
        if (!counts[booking.clientEmail]) {
          counts[booking.clientEmail] = { total: 0, pending: 0, confirmed: 0, completed: 0, cancelled: 0 };
        }
        counts[booking.clientEmail].total += 1;
        if (counts[booking.clientEmail][booking.status] !== undefined) {
          counts[booking.clientEmail][booking.status] += 1;
        }
      });

      return deepClone(state.clients)
        .sort((a, b) => a.name.localeCompare(b.name))
        .map((client) => ({ ...client, stats: counts[client.email] || { total: 0, pending: 0, confirmed: 0, completed: 0, cancelled: 0 } }));
    },

    async adjustCredits(email, amount) {
      const student = getStudentByEmail(email);
      if (!student) throw new Error('Client not found.');
      student.credits = Math.max(0, Number(student.credits || 0) + Number(amount || 0));
      logAudit('credits.adjusted', `${student.email}: ${amount > 0 ? '+' : ''}${amount}`, 'admin');
      saveState();
      return student.credits;
    },

    async listServices() {
      return deepClone(state.services).sort((a, b) => a.name.localeCompare(b.name));
    },

    async createService(payload) {
      const service = normalizeService(payload);
      if (!service.name) throw new Error('Service name is required.');
      if (!service.duration || service.duration < 15) throw new Error('Duration must be at least 15 minutes.');
      if (service.price < 0) throw new Error('Price must be 0 or greater.');
      if (!service.weeklySlots.length) throw new Error('Add at least one weekly slot/day.');

      state.services.push(service);
      logAudit('service.created', `Service ${service.name}`, 'admin');
      saveState();
      return deepClone(service);
    },

    async saveService(payload) {
      return api.createService(payload);
    },

    async deleteService(serviceId) {
      const service = getServiceById(serviceId);
      state.services = state.services.filter((s) => s.id !== serviceId);
      state.bookings = state.bookings.filter((b) => b.serviceId !== serviceId || b.status === 'completed');
      logAudit('service.deleted', `Service ${service ? service.name : serviceId}`, 'admin');
      saveState();
      return true;
    },

    async listBookableSlots(serviceId, date) {
      const service = ensureServiceAndDate(serviceId, date);
      const times = buildSlots(service, date);

      return times.map((time) => {
        const used = state.bookings.filter((booking) =>
          booking.serviceId === service.id && booking.date === date && booking.time === time && booking.status !== 'cancelled'
        ).length;

        return {
          time,
          available: used < service.capacity,
          openSpots: Math.max(service.capacity - used, 0)
        };
      });
    },

    async listBookings(filters) {
      const f = filters || {};
      let rows = state.bookings.slice();

      if (f.serviceId && f.serviceId !== 'all') rows = rows.filter((b) => b.serviceId === f.serviceId);
      if (f.status && f.status !== 'all') rows = rows.filter((b) => b.status === f.status);
      if (f.date) rows = rows.filter((b) => b.date === f.date);
      if (f.clientEmail) rows = rows.filter((b) => b.clientEmail === String(f.clientEmail).toLowerCase());

      rows.sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`));
      return deepClone(rows);
    },

    async createBooking(payload) {
      const service = ensureServiceAndDate(payload.serviceId, payload.date);
      const time = String(payload.time || '');
      if (!time) throw new Error('Please choose a time.');

      const nowDate = new Date();
      nowDate.setHours(0, 0, 0, 0);
      const requestedDate = new Date(payload.date + 'T00:00:00');
      if (requestedDate < nowDate) throw new Error('Cannot book a past date.');

      const email = String(payload.clientEmail || '').trim().toLowerCase();
      const name = String(payload.clientName || '').trim();
      const phone = cleanPhone(payload.clientPhone || '');
      if (!isEmail(email)) throw new Error('Valid client email is required.');
      if (!name) throw new Error('Client name is required.');
      if (!isPhone(phone)) throw new Error('Phone format is invalid.');

      const client = getStudentByEmail(email);
      if (!client) throw new Error('Create an account first to track your bookings.');

      const slot = (await api.listBookableSlots(service.id, payload.date)).find((s) => s.time === time);
      if (!slot) throw new Error('Selected time is invalid for this service/date.');
      if (!slot.available) throw new Error('Selected time is already full.');

      const duplicate = state.bookings.find((b) =>
        b.clientEmail === email && b.serviceId === service.id && b.date === payload.date && b.time === time && b.status !== 'cancelled'
      );
      if (duplicate) throw new Error('You already have a booking for this slot.');

      if (payload.consumeCredit && Number(client.credits || 0) <= 0) {
        throw new Error('No credits available. Please refill credits first.');
      }

      if (payload.consumeCredit) {
        client.credits = Math.max(0, client.credits - 1);
        logAudit('credits.used', `${client.email} used 1 credit`, client.email);
      }

      const booking = normalizeBooking({
        clientId: client.id,
        clientName: name,
        clientEmail: email,
        clientPhone: phone,
        serviceId: service.id,
        serviceName: service.name,
        date: payload.date,
        time,
        notes: payload.notes || '',
        price: Number(payload.price || service.price),
        status: payload.status || 'pending'
      });

      state.bookings.push(booking);
      logAudit('booking.created', `${booking.clientEmail} booked ${booking.serviceName} ${booking.date} ${booking.time}`, booking.clientEmail);
      saveState();
      return deepClone(booking);
    },

    async updateBookingStatus(bookingId, nextStatus, options) {
      if (!STATUS_VALUES.includes(nextStatus)) throw new Error('Invalid booking status.');
      const booking = state.bookings.find((b) => b.id === bookingId);
      if (!booking) throw new Error('Booking not found.');

      booking.status = nextStatus;
      booking.updatedAt = new Date().toISOString();

      const opts = options || {};
      if (nextStatus === 'cancelled' && opts.refundCredit) {
        const client = getStudentByEmail(booking.clientEmail);
        if (client) client.credits += 1;
      }

      logAudit('booking.status', `${booking.id} -> ${nextStatus}`, 'admin');
      saveState();
      return deepClone(booking);
    },

    async sendReminder(bookingId) {
      const booking = state.bookings.find((b) => b.id === bookingId);
      if (!booking) throw new Error('Booking not found.');
      const phone = booking.clientPhone || (getStudentByEmail(booking.clientEmail) || {}).phone;
      if (!phone) throw new Error('No phone number found for this student.');

      const message = `Reminder: ${booking.serviceName} on ${booking.date} at ${booking.time}.`;
      const link = `https://wa.me/${cleanPhone(phone)}?text=${encodeURIComponent(message)}`;
      if (typeof window !== 'undefined' && window.open) window.open(link, '_blank');

      logAudit('booking.reminder', `Reminder sent for ${booking.id}`, 'admin');
      saveState();
      return true;
    },

    async addExpense(payload) {
      const expense = normalizeExpense(payload);
      if (!expense.note) throw new Error('Expense note is required.');
      if (expense.amount <= 0) throw new Error('Expense amount must be greater than 0.');

      state.expenses.push(expense);
      logAudit('expense.added', `${expense.note} (${expense.amount})`, 'admin');
      saveState();
      return deepClone(expense);
    },

    async setTaxConfig(province, customRate) {
      const code = String(province || 'ON').toUpperCase();
      if (!PROVINCE_RATES.hasOwnProperty(code)) throw new Error('Invalid province code.');
      const rate = code === 'CUSTOM' ? Number(customRate || 0) : PROVINCE_RATES[code];
      if (rate < 0 || rate > 1) throw new Error('Tax rate must be between 0 and 1.');

      state.taxConfig = { province: code, rate };
      logAudit('tax.updated', `${code} (${(rate * 100).toFixed(2)}%)`, 'admin');
      saveState();
      return deepClone(state.taxConfig);
    },

    async getTaxConfig() {
      return deepClone(state.taxConfig);
    },

    async getFinancialSummary() {
      const completed = state.bookings.filter((b) => b.status === 'completed');
      const gross = completed.reduce((sum, b) => sum + Number(b.price || 0), 0);
      const expenses = state.expenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);
      const tax = gross * Number(state.taxConfig.rate || 0);
      return { gross, expenses, tax, profit: gross - expenses - tax };
    },

    async getWeeklyEarnings() {
      const labels = [];
      const dataPoints = [];
      const now = new Date();

      for (let i = 6; i >= 0; i -= 1) {
        const date = new Date(now);
        date.setDate(now.getDate() - i);
        const iso = date.toISOString().split('T')[0];
        labels.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
        const total = state.bookings
          .filter((b) => b.date === iso && b.status === 'completed')
          .reduce((sum, b) => sum + Number(b.price || 0), 0);
        dataPoints.push(total);
      }

      return { labels, dataPoints };
    },

    async listAuditTrail(limit) {
      const rows = state.auditTrail.slice(0, Number(limit || 100));
      return deepClone(rows);
    },

    async exportSystemData() {
      const json = JSON.stringify(state, null, 2);

      if (typeof document !== 'undefined' && typeof Blob !== 'undefined') {
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `studioflow_backup_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
      }

      return json;
    }
  };

  saveState();
  window.StudioFlowAPI = api;
})();
