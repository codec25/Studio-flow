#!/usr/bin/env bash
set -euo pipefail

APP_NAME="studioflow-web-app"
OUT_DIR="dist"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
ZIP_PATH="${OUT_DIR}/${APP_NAME}-${TIMESTAMP}.zip"

mkdir -p "$OUT_DIR"

zip -r "$ZIP_PATH" \
  index.html book.html clients.html services.html portal.html register.html auth.html \
  app-api.js app-ui.js pwa-init.js sw.js manifest.webmanifest offline.html readme.md APP_DOCUMENTATION.md icons

echo "Created: $ZIP_PATH"
