(function () {
  const THEME_KEY = 'studioflow_theme';

  const nav = [
    { href: 'index.html', label: 'Dashboard' },
    { href: 'services.html', label: 'Services' },
    { href: 'clients.html', label: 'Clients' },
    { href: 'book.html', label: 'Book' },
    { href: 'portal.html', label: 'Portal' },
    { href: 'register.html', label: 'Register' }
  ];

  function currentPath() {
    const file = location.pathname.split('/').pop();
    return file || 'index.html';
  }

  function injectStyle() {
    if (document.getElementById('sf-appbar-style')) return;

    const css = document.createElement('style');
    css.id = 'sf-appbar-style';
    css.textContent = `
      :root {
        --sf-bg: #f8fafc;
        --sf-text: #0f172a;
        --sf-muted: #64748b;
        --sf-line: #e2e8f0;
        --sf-surface: #ffffff;
        --sf-brand: #0f766e;
      }

      html.sf-dark {
        --sf-bg: #0b1220;
        --sf-text: #e5e7eb;
        --sf-muted: #94a3b8;
        --sf-line: #334155;
        --sf-surface: #111827;
        --sf-brand: #14b8a6;
      }

      html, body { background: var(--sf-bg) !important; color: var(--sf-text) !important; }
      body { padding-top: 78px !important; }

      .sf-appbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 10px 14px;
        background: color-mix(in oklab, var(--sf-surface) 88%, transparent);
        border-bottom: 1px solid var(--sf-line);
        backdrop-filter: blur(10px);
      }

      .sf-left, .sf-right, .sf-links { display: flex; align-items: center; gap: 8px; }
      .sf-links { overflow-x: auto; scrollbar-width: none; }
      .sf-links::-webkit-scrollbar { display: none; }

      .sf-brand {
        font-size: 13px;
        font-weight: 900;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--sf-brand);
        white-space: nowrap;
      }

      .sf-btn {
        border-radius: 999px;
        border: 1px solid var(--sf-line);
        background: var(--sf-surface);
        color: var(--sf-text);
        padding: 7px 11px;
        font-size: 12px;
        font-weight: 800;
        line-height: 1;
        cursor: pointer;
        white-space: nowrap;
      }

      .sf-btn:hover { border-color: var(--sf-brand); color: var(--sf-brand); }
      .sf-btn.active { background: var(--sf-brand); border-color: var(--sf-brand); color: white; }

      html.sf-dark .card,
      html.sf-dark .shell,
      html.sf-dark .input-field,
      html.sf-dark .field,
      html.sf-dark input,
      html.sf-dark select,
      html.sf-dark textarea,
      html.sf-dark [class*="bg-white"],
      html.sf-dark [class*="bg-slate-50"],
      html.sf-dark [class*="bg-teal-50"] {
        background-color: var(--sf-surface) !important;
        color: var(--sf-text) !important;
        border-color: var(--sf-line) !important;
      }

      html.sf-dark [class*="text-slate-"],
      html.sf-dark [class*="text-teal-"],
      html.sf-dark [class*="text-indigo-"] {
        color: var(--sf-text) !important;
      }

      @media (max-width: 900px) {
        .sf-brand { display: none; }
        .sf-right .sf-btn { padding: 7px 10px; }
      }
    `;

    document.head.appendChild(css);
  }

  function getTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function setTheme(theme) {
    localStorage.setItem(THEME_KEY, theme);
    document.documentElement.classList.toggle('sf-dark', theme === 'dark');
    const btn = document.getElementById('sfThemeBtn');
    if (btn) btn.textContent = theme === 'dark' ? 'Light' : 'Dark';
  }

  function buildBar() {
    if (document.getElementById('sfAppBar')) return;

    const bar = document.createElement('div');
    bar.id = 'sfAppBar';
    bar.className = 'sf-appbar';

    const left = document.createElement('div');
    left.className = 'sf-left';

    const brand = document.createElement('span');
    brand.className = 'sf-brand';
    brand.textContent = 'StudioFlow';

    const back = document.createElement('button');
    back.className = 'sf-btn';
    back.type = 'button';
    back.textContent = 'Back';
    back.addEventListener('click', function () {
      if (history.length > 1) history.back();
      else location.href = 'index.html';
    });

    const links = document.createElement('div');
    links.className = 'sf-links';
    const here = currentPath();
    nav.forEach((item) => {
      const a = document.createElement('a');
      a.href = item.href;
      a.className = 'sf-btn' + (item.href === here ? ' active' : '');
      a.textContent = item.label;
      links.appendChild(a);
    });

    left.appendChild(brand);
    left.appendChild(back);
    left.appendChild(links);

    const right = document.createElement('div');
    right.className = 'sf-right';

    const theme = document.createElement('button');
    theme.id = 'sfThemeBtn';
    theme.className = 'sf-btn';
    theme.type = 'button';
    theme.addEventListener('click', function () {
      setTheme(getTheme() === 'dark' ? 'light' : 'dark');
    });

    const home = document.createElement('a');
    home.href = 'index.html';
    home.className = 'sf-btn';
    home.textContent = 'Home';

    right.appendChild(theme);
    right.appendChild(home);

    bar.appendChild(left);
    bar.appendChild(right);
    document.body.prepend(bar);

    setTheme(getTheme());
  }

  function init() {
    injectStyle();
    buildBar();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
